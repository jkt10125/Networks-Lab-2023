/*
** Date: 08/01/2023 | Time: 13:29:58
** Name: Jay Kumar Thakur
** Rollno: 20CS30024
*/



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// max allowable buffer size
size_t bufsize = 100;

int main() {

    int sockfd; // variable for socket creation
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    // checking for socket creation failures
    if (sockfd < 0) {
        perror("Socket creation failed!");
        exit(0);
    }
    else {
        printf("Socket Created Successfully!\n");
    }
    
    struct sockaddr_in ServerAddress;

    // setting the serveraddress specifications
    ServerAddress.sin_family = AF_INET;
    inet_aton("127.0.0.1", &ServerAddress.sin_addr);
    ServerAddress.sin_port = htons(20000);

    int connectStatus; // making a connect call to the server
    connectStatus = connect(sockfd, (struct sockaddr *) &ServerAddress, sizeof(ServerAddress));

    // checking for connection failures
    if (connectStatus < 0) {
        
        perror("Connection failed!");
        exit(0);
    }
    else {
        
        printf("Connection Established!\n");
    }

    // creating send and receive buffer with sufficient size
    char *send_buf = (char *) malloc(sizeof(char) * bufsize);

    char *recv_buf = (char *) malloc(sizeof(char) * bufsize);

    recv_buf[0] = '\0';
    int len = 0;
    
    // taking input from the user and fetching data from the server
    // until user enters "-1"
    while (strcmp(send_buf, "-1")) {
        
        len = getline(&send_buf, &bufsize, stdin);

        // last character is '\n' so ignoring it
        send_buf[--len] = '\0';

        // sending the data to the server
        send(sockfd, send_buf, len, 0);

        // receiving the answer from the server
        int readLength = recv(sockfd, recv_buf, bufsize, 0);

        printf("%s\n", recv_buf);

    }


    // closing the socket
    close(sockfd);

    return 0;
}